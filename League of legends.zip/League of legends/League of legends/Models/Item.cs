﻿using System;
using System.Collections.Generic;

namespace League_of_legends.Models;

public partial class Item
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public int? Cost { get; set; }

    public string? Stats { get; set; }

    public string? PassiveEffects { get; set; }

    public virtual ICollection<Champion> Champions { get; set; } = new List<Champion>();
}
