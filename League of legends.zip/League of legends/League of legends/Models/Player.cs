﻿using System;
using System.Collections.Generic;

namespace League_of_legends.Models;

public partial class Player
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public int? Age { get; set; }

    public string? Region { get; set; }

    public virtual ICollection<Mastery> Masteries { get; set; } = new List<Mastery>();

    public virtual ICollection<Rank> Ranks { get; set; } = new List<Rank>();
}
