﻿using System;
using System.Collections.Generic;

namespace League_of_legends.Models;

public partial class Mastery
{
    public int Id { get; set; }

    public int ChampId { get; set; }

    public int PlayerId { get; set; }

    public int? MasteryLevel { get; set; }

    public int? MasteryPoints { get; set; }

    public virtual Champion Champ { get; set; } = null!;

    public virtual Player Player { get; set; } = null!;
}
