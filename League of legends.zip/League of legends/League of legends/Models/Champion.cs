﻿using System;
using System.Collections.Generic;

namespace League_of_legends.Models;

public partial class Champion
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public int? Health { get; set; }

    public int? Ad { get; set; }

    public int? Ap { get; set; }

    public string? Lore { get; set; }

    public virtual ICollection<Ability> Abilities { get; set; } = new List<Ability>();

    public virtual ICollection<Mastery> Masteries { get; set; } = new List<Mastery>();

    public virtual ICollection<Item> Items { get; set; } = new List<Item>();

    public virtual ICollection<Role> Roles { get; set; } = new List<Role>();

    public virtual ICollection<Rune> Runes { get; set; } = new List<Rune>();
}
