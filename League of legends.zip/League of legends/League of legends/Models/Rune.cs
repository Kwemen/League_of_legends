﻿using System;
using System.Collections.Generic;

namespace League_of_legends.Models;

public partial class Rune
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Effects { get; set; }

    public virtual ICollection<Champion> Champions { get; set; } = new List<Champion>();
}
