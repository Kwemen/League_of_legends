﻿using System;
using System.Collections.Generic;

namespace League_of_legends.Models;

public partial class Rank
{
    public int Id { get; set; }

    public int PlayerId { get; set; }

    public string? Tier { get; set; }

    public string? Division { get; set; }

    public int? Points { get; set; }

    public virtual Player Player { get; set; } = null!;
}
