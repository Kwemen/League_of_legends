﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace League_of_legends.Models;

public partial class LeagueOfLegendsContext : DbContext
{
    public LeagueOfLegendsContext()
    {
    }

    public LeagueOfLegendsContext(DbContextOptions<LeagueOfLegendsContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Ability> Abilities { get; set; }

    public virtual DbSet<Champion> Champions { get; set; }

    public virtual DbSet<Item> Items { get; set; }

    public virtual DbSet<Mastery> Masteries { get; set; }

    public virtual DbSet<Player> Players { get; set; }

    public virtual DbSet<Rank> Ranks { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<Rune> Runes { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("Name=ConnectionStrings:DefaultConnection");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Ability>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Abilitie__3213E83F616E1F42");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.ChampionId).HasColumnName("champion_id");
            entity.Property(e => e.Cooldown).HasColumnName("cooldown");
            entity.Property(e => e.Description)
                .HasColumnType("text")
                .HasColumnName("description");
            entity.Property(e => e.Dmg).HasColumnName("dmg");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("name");

            entity.HasOne(d => d.Champion).WithMany(p => p.Abilities)
                .HasForeignKey(d => d.ChampionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Abilities__champ__3E52440B");
        });

        modelBuilder.Entity<Champion>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Champion__3213E83FCCB2A150");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Ad).HasColumnName("ad");
            entity.Property(e => e.Ap).HasColumnName("ap");
            entity.Property(e => e.Health).HasColumnName("health");
            entity.Property(e => e.Lore)
                .HasColumnType("text")
                .HasColumnName("lore");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("name");

            entity.HasMany(d => d.Items).WithMany(p => p.Champions)
                .UsingEntity<Dictionary<string, object>>(
                    "ChampionItem",
                    r => r.HasOne<Item>().WithMany()
                        .HasForeignKey("ItemId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ChampionI__item___619B8048"),
                    l => l.HasOne<Champion>().WithMany()
                        .HasForeignKey("ChampionId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ChampionI__champ__60A75C0F"),
                    j =>
                    {
                        j.HasKey("ChampionId", "ItemId").HasName("PK__Champion__0CEA5BD23D280EDC");
                        j.ToTable("ChampionItems");
                        j.IndexerProperty<int>("ChampionId").HasColumnName("champion_id");
                        j.IndexerProperty<int>("ItemId").HasColumnName("item_id");
                    });

            entity.HasMany(d => d.Roles).WithMany(p => p.Champions)
                .UsingEntity<Dictionary<string, object>>(
                    "ChampionRole",
                    r => r.HasOne<Role>().WithMany()
                        .HasForeignKey("RoleId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ChampionR__role___3B75D760"),
                    l => l.HasOne<Champion>().WithMany()
                        .HasForeignKey("ChampionId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ChampionR__champ__3A81B327"),
                    j =>
                    {
                        j.HasKey("ChampionId", "RoleId").HasName("PK__Champion__1EAAED73C2A85AC3");
                        j.ToTable("ChampionRoles");
                        j.IndexerProperty<int>("ChampionId").HasColumnName("champion_id");
                        j.IndexerProperty<int>("RoleId").HasColumnName("role_id");
                    });

            entity.HasMany(d => d.Runes).WithMany(p => p.Champions)
                .UsingEntity<Dictionary<string, object>>(
                    "ChampionRune",
                    r => r.HasOne<Rune>().WithMany()
                        .HasForeignKey("RuneId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ChampionR__rune___5DCAEF64"),
                    l => l.HasOne<Champion>().WithMany()
                        .HasForeignKey("ChampionId")
                        .OnDelete(DeleteBehavior.ClientSetNull)
                        .HasConstraintName("FK__ChampionR__champ__5CD6CB2B"),
                    j =>
                    {
                        j.HasKey("ChampionId", "RuneId").HasName("PK__Champion__8F5BBB4FEFA27F80");
                        j.ToTable("ChampionRunes");
                        j.IndexerProperty<int>("ChampionId").HasColumnName("champion_id");
                        j.IndexerProperty<int>("RuneId").HasColumnName("rune_id");
                    });
        });

        modelBuilder.Entity<Item>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Items__3213E83F03E8ED83");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Cost).HasColumnName("cost");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.PassiveEffects)
                .HasColumnType("text")
                .HasColumnName("passive_effects");
            entity.Property(e => e.Stats)
                .HasColumnType("text")
                .HasColumnName("stats");
        });

        modelBuilder.Entity<Mastery>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Mastery__3213E83F2B4E8E5B");

            entity.ToTable("Mastery");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.ChampId).HasColumnName("champ_id");
            entity.Property(e => e.MasteryLevel).HasColumnName("mastery_level");
            entity.Property(e => e.MasteryPoints).HasColumnName("mastery_points");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");

            entity.HasOne(d => d.Champ).WithMany(p => p.Masteries)
                .HasForeignKey(d => d.ChampId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Mastery__champ_i__46E78A0C");

            entity.HasOne(d => d.Player).WithMany(p => p.Masteries)
                .HasForeignKey(d => d.PlayerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Mastery__player___47DBAE45");
        });

        modelBuilder.Entity<Player>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Players__3213E83F5291F51C");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Age).HasColumnName("age");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.Region)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("region");
        });

        modelBuilder.Entity<Rank>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Rank__3213E83F0C2A366E");

            entity.ToTable("Rank");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Division)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("division");
            entity.Property(e => e.PlayerId).HasColumnName("player_id");
            entity.Property(e => e.Points).HasColumnName("points");
            entity.Property(e => e.Tier)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("tier");

            entity.HasOne(d => d.Player).WithMany(p => p.Ranks)
                .HasForeignKey(d => d.PlayerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__Rank__player_id__4AB81AF0");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Roles__3213E83FDAF279D5");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Description)
                .HasColumnType("text")
                .HasColumnName("description");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Rune>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Runes__3213E83F3AED3A28");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Effects)
                .HasColumnType("text")
                .HasColumnName("effects");
            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false)
                .HasColumnName("name");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
