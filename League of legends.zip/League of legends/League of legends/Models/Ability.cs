﻿using System;
using System.Collections.Generic;

namespace League_of_legends.Models;

public partial class Ability
{
    public int Id { get; set; }

    public int ChampionId { get; set; }

    public string Name { get; set; } = null!;

    public int? Dmg { get; set; }

    public int? Cooldown { get; set; }

    public string? Description { get; set; }

    public virtual Champion Champion { get; set; } = null!;
}
