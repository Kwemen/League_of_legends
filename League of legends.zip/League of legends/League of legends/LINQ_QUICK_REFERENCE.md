# LINQ Iskalnik - Hitri Pregled

## ?? Kaj je bilo implementirano?

### 1. PlayersController.Index()
```csharp
// ?? Parametri iz forme:
public async Task<IActionResult> Index(
    string searchString,   // "ali"
    string filterRegion,   // "EU"
    string sortBy)         // "name_asc"

// ?? Tri LINQ operacije:
// 1. WHERE + CONTAINS - iskalnik
playersQuery.Where(p => p.Name.ToLower().Contains(searchString.ToLower()));

// 2. WHERE - filter po regiji
playersQuery.Where(p => p.Region == filterRegion);

// 3. ORDERBY - sortiranje
playersQuery.OrderBy(p => p.Name);
```

### 2. ChampionsController.Index()
```csharp
// ?? Parametri:
// - searchString (iskalnik)
// - filterStat (fizi�ni, magi�ni, tanki, uravnote�eni)
// - sortBy (po imenu, AD, AP, zdravju)

// ?? Filtriranje po statistiki:
"high_ad" => championsQuery.Where(c => c.Ad > 70)
"high_ap" => championsQuery.Where(c => c.Ap > 70)
"balanced" => championsQuery.Where(c => 
    c.Ad > 50 && c.Ap > 50 && c.Health > 400)
```

### 3. ItemsController.Index()
```csharp
// ?? Parametri:
// - searchString (iskalnik)
// - filterCost (poceni, srednje, dragi)
// - sortBy (po imenu, ceni)

// ?? Filtriranje po ceni:
"cheap" => itemsQuery.Where(i => i.Cost < 1000)
"medium" => itemsQuery.Where(i => i.Cost >= 1000 && i.Cost < 2000)
"expensive" => itemsQuery.Where(i => i.Cost >= 2000)
```

---

## ?? LINQ Operacije - Razlaga

### 1?? WHERE - Filtriranje z pogojem

```csharp
// Sintaksa
playersQuery.Where(p => p.Region == "EU");

// Razlaga:
// - p => je parameter (vsak posamezni element)
// - p.Region == "EU" je pogoj
// - vrne samo elemente, ki izpolnjujejo pogoj

// Primeri:
Where(p => p.Age > 25)              // starej�i od 25
Where(p => p.Region != "NA")        // ne iz NA
Where(p => p.Age > 25 && p.Name.StartsWith("A"))  // AND pogoj
```

### 2?? CONTAINS - Iskanje v tekstu

```csharp
// Sintaksa
playersQuery.Where(p => p.Name.Contains("ali"));

// Razlaga:
// - Contains("ali") preverka ali string vsebuje "ali"
// - "Milan" vsebuje "ali" ?
// - "Alison" vsebuje "ali" ?
// - "Ana" NE vsebuje "ali" ?

// Z case-insensitive:
playersQuery.Where(p => p.Name.ToLower().Contains(search.ToLower()));
// - "ALI" bo na�el "ali", "Ali", "ALI"
```

### 3?? ORDERBY - Sortiranje nara��ajo�e

```csharp
// Sintaksa
playersQuery.OrderBy(p => p.Name);

// Razlaga:
// - Sortira po Name (A-Z, 0-9)
// - Rezultat: "Alison", "Ana", "Malik", "Milan", "Petra"

// Primeri:
OrderBy(p => p.Name)        // A-Z
OrderBy(p => p.Age)         // od najmanj�e
OrderBy(p => p.Id)          // po ID
```

### 4?? ORDERBYDESCENDING - Sortiranje padajo�e

```csharp
// Sintaksa
playersQuery.OrderByDescending(p => p.Age);

// Razlaga:
// - Sortira po Age (od najve�jega)
// - Rezultat: 30, 28, 25, 22, 20

// Primeri:
OrderByDescending(p => p.Name)      // Z-A
OrderByDescending(p => p.Health)    // od najbolj tankih
OrderByDescending(p => p.Cost)      // najdra�ji
```

---

## ?? Kombiniranje operacij

### Primer: Players iskanje + filter + sortiranje

```csharp
IQueryable<Player> query = _context.Players;

// Korak 1: Iskalnik (WHERE + CONTAINS)
if (!string.IsNullOrEmpty(searchString))
{
    query = query.Where(p => p.Name.ToLower().Contains(searchString.ToLower()));
}

// Korak 2: Filter (WHERE ==)
if (!string.IsNullOrEmpty(filterRegion))
{
    query = query.Where(p => p.Region == filterRegion);
}

// Korak 3: Sortiranje (ORDERBY)
query = sortBy switch
{
    "name_asc" => query.OrderBy(p => p.Name),
    "name_desc" => query.OrderByDescending(p => p.Name),
    "age_asc" => query.OrderBy(p => p.Age),
    "age_desc" => query.OrderByDescending(p => p.Age),
    _ => query.OrderBy(p => p.Id)
};

// Korak 4: Konvertuj v seznam (IZVR�IMO QUERY)
var players = await query.ToListAsync();
```

---

## ?? Vizualni primer

### Podatki v bazi:
```
Milan    Age: 28, Region: EU
Alison   Age: 22, Region: NA
Ana      Age: 25, Region: EU
Malik    Age: 30, Region: BR
Petra    Age: 20, Region: EU
```

### Korak 1: WHERE + CONTAINS
```csharp
.Where(p => p.Name.ToLower().Contains("ali"))
```
**Rezultat:** Milan ?, Alison ?, Malik ?

### Korak 2: WHERE ==
```csharp
.Where(p => p.Region == "EU")
```
**Rezultat:** Milan ?

### Korak 3: ORDERBY
```csharp
.OrderBy(p => p.Name)
```
**Rezultat:** Milan

### ?? KON�NI REZULTAT:
```
[1 rezultat]
Milan  (28 let, EU)
```

---

## ?? Wichtig: IQueryable vs ToList

```csharp
// ? Naredi isto v aplikaciji (po�asi)
var players = _context.Players.ToList();
var filtered = players.Where(p => p.Age > 20).ToList();

// ? Naredi v bazi (hitro)
var filtered = await _context.Players
    .Where(p => p.Age > 20)
    .ToListAsync();
```

**Zakaj je IQueryable bolje?**
- Filtri se izvr�ijo v SQL-u (baza)
- Samo potrebni podatki se prinesejo
- Je hitrej�e za velike koli�ine podatkov

---

## ??? Kako spremeniti filtri?

### Primer: Dodaj filter po ceni za Players

**1?? Dodaj v kontroler:**
```csharp
if (!string.IsNullOrEmpty(minCost) && int.TryParse(minCost, out var min))
{
    playersQuery = playersQuery.Where(p => p.Id > min);  // Primer
}
```

**2?? Dodaj v HTML formo:**
```html
<input type="text" name="minCost" placeholder="Min cost" />
```

**3?? Po�lji v View:**
```csharp
ViewData["MinCost"] = minCost;
```

---

## ?? Povzetek - 3 Glavne LINQ Operacije

| Operacija | Kaj dela | Primer |
|-----------|----------|--------|
| **WHERE + CONTAINS** | Iskanje v tekstu | `Where(p => p.Name.Contains("ali"))` |
| **WHERE ==** | Natan�na primerjava | `Where(p => p.Region == "EU")` |
| **ORDERBY** | Sortiraj | `OrderBy(p => p.Name)` ali `OrderByDescending(p => p.Age)` |

---

## ?? Kako testirati?

1. **Po�eni app:**
   ```bash
   dotnet run
   ```

2. **Pojdi na stranmi:**
   - Players: `https://localhost:5001/Players`
   - Champions: `https://localhost:5001/Champions`
   - Items: `https://localhost:5001/Items`

3. **Testiraj:**
   - Iskalnik: Vnesi besedo
   - Filter: Izberi iz dropdown
   - Sortiranje: Izberi sorting opcijo
   - Klikni "Search"

4. **Rezultat:** Vidi� filtrirane podatke! ?

---

## ?? Dodatne Informacije

Ve� informacij v datotekah:
- `LINQ_GUIDE.md` - Detaljne razlage z primeri
- `SEARCH_FILTER_GUIDE.md` - Prakti�ni vodnik
- `LINQ_EXAMPLES.cs` - Kodni primeri za referenco

Sve tri kode (PlayersController, ChampionsController, ItemsController) imajo enak vzorec - samo razli�ne filtiranja glede na podatke.
