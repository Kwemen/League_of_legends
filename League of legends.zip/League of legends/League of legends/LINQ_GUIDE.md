# LINQ in EF Core - Detaljne Razlage

## Kaj je LINQ?

**LINQ** (Language Integrated Query) je naprosto povedano **jezik za iskanje in filtriranje podatkov** v C#. Omogo�a ci, da pi�e c kodo, ki je podobna SQL-u, vendar neposredno v C#.

## Kako se uporabljajo v na�i aplikaciji?

### 1. WHERE - FILTRIRANJE PODATKOV

**Kaj deluje?** WHERE izbira samo podatke, ki izpolnjujejo pogoj.

```csharp
// Primer 1: Najdi vse igralce iz regije "EU"
var euPlayers = _context.Players.Where(p => p.Region == "EU");
// Rezultat: [ { Id: 1, Name: "Milan", Region: "EU" }, { Id: 3, Name: "Ana", Region: "EU" } ]

// Primer 2: Najdi vselike z AD (Attack Damage) > 70
var physicalChampions = _context.Champions.Where(c => c.Ad > 70);

// Primer 3: Najdi vse igralce, starej�e od 25 let
var seniorPlayers = _context.Players.Where(p => p.Age > 25);

// Primer 4: Kombinacija pogojev (AND - morajo biti izpolnjeni vsi pogoji)
var filteredPlayers = _context.Players.Where(p => 
    p.Region == "EU" && p.Age > 20);
// Rezultat: samo igralci iz EU, starej�i od 20 let
```

**Kako se izra�una v bazi:**
```sql
-- WHERE se v bazi izvede kot SQL WHERE stavek:
SELECT * FROM Players WHERE Region = 'EU'
SELECT * FROM Champions WHERE Ad > 70
```

---

### 2. CONTAINS - ISKANJE V BESEDILIH

**Kaj deluje?** CONTAINS preveri ali string vsebuje iskani tekst. Idealno za iskalnike.

```csharp
// Primer 1: Najdi vse like, ki imajo "ash" v imenu
string search = "ash";
var results = _context.Champions.Where(c => 
    c.Name.Contains(search));
// Rezultat: vrne "Ashe", "Ashen Fist", itd.

// Primer 2: Iskanje brez razlike med malimi in VELIKIMI �RKAMI
var results = _context.Players.Where(p => 
    p.Name.ToLower().Contains(search.ToLower()));
// Rezultat: Ko i��e� "ALI", najde� "ali", "Ali", "ALI", itd.

// Primer 3: Iskanje samo �e beseda obstaja
if (!string.IsNullOrEmpty(searchString))
{
    // Iskalni tekst ni prazen, zato ga uporabi
    var players = _context.Players.Where(p => 
        p.Name.ToLower().Contains(searchString.ToLower()));
}
```

**Kako se izra�una v bazi:**
```sql
-- CONTAINS se v bazi izvede kot SQL LIKE stavek:
SELECT * FROM Champions WHERE Name LIKE '%ash%'
SELECT * FROM Players WHERE LOWER(Name) LIKE LOWER('%ali%')
```

**Primerjava iskanja:**
```csharp
// ? Natan�na iskanja - NE DELUJE dobro za iskalnik
var results = _context.Players.Where(p => p.Name == "Alison");
// Vrne samo to�no "Alison", ne pa "ali", "Alison", itd.

// ? CONTAINS iskanja - DELUJE dobro za iskalnik
var results = _context.Players.Where(p => 
    p.Name.ToLower().Contains(search.ToLower()));
// Vrne vse, ki vsebujejo "ali" - "Alison", "Malik", "Pali", itd.
```

---

### 3. ORDERBY - SORTIRANJE REZULTATOV

**Kaj deluje?** OrderBy sortira rezultate. OrderBy = nara��ajo�e, OrderByDescending = padajo�e.

```csharp
// Primer 1: Sortiraj po imenu A-Z (nara��ajo�e)
var sorted = _context.Players.OrderBy(p => p.Name);
// Rezultat: [ "Alison", "Bojan", "Petra" ]

// Primer 2: Sortiraj po imenu Z-A (padajo�e)
var sorted = _context.Players.OrderByDescending(p => p.Name);
// Rezultat: [ "Petra", "Bojan", "Alison" ]

// Primer 3: Sortiraj po starosti - od najmanj�e
var sorted = _context.Players.OrderBy(p => p.Age);
// Rezultat: [ { Age: 18 }, { Age: 25 }, { Age: 35 } ]

// Primer 4: Sortiraj po starosti - od najve�je
var sorted = _context.Players.OrderByDescending(p => p.Age);
// Rezultat: [ { Age: 35 }, { Age: 25 }, { Age: 18 } ]

// Primer 5: Sortiraj po zdravju - od najmo�nej�ih
var sorted = _context.Champions.OrderByDescending(c => c.Health);
```

**Kako se izra�una v bazi:**
```sql
-- OrderBy se v bazi izvede kot SQL ORDER BY stavek:
SELECT * FROM Players ORDER BY Name ASC      -- A-Z
SELECT * FROM Players ORDER BY Age DESC      -- od najbolj star
SELECT * FROM Champions ORDER BY Health DESC -- od najmo�nej�ih
```

---

## Primeri uporabe v na�i aplikaciji

### Primer 1: Iskanje in filtriranje Players

```csharp
// V PlayersController.cs Index metodi:
IQueryable<Player> playersQuery = _context.Players;

// Korak 1: Iskalnik (CONTAINS)
if (!string.IsNullOrEmpty(searchString))
{
    playersQuery = playersQuery.Where(p => 
        p.Name.ToLower().Contains(searchString.ToLower()));
    // Ali isku� "petr", ali si vnesel "PETR", ali "Petr" - NAJDE �e vseh!
}

// Korak 2: Filter po regiji (WHERE z ==)
if (!string.IsNullOrEmpty(filterRegion) && filterRegion != "All")
{
    playersQuery = playersQuery.Where(p => p.Region == filterRegion);
}

// Korak 3: Sortiranje (ORDERBY)
playersQuery = sortBy switch
{
    "name_asc" => playersQuery.OrderBy(p => p.Name),
    "name_desc" => playersQuery.OrderByDescending(p => p.Name),
    "age_asc" => playersQuery.OrderBy(p => p.Age),
    "age_desc" => playersQuery.OrderByDescending(p => p.Age),
    _ => playersQuery.OrderBy(p => p.Id)
};

// Korak 4: Konvertuj v seznam in �akaj rezultat
var players = await playersQuery.ToListAsync();
```

**Kako deluje korak za korakom:**

```
Recimo da v bazi obstajajo ti igralci:
1. { Id: 1, Name: "Milan", Age: 28, Region: "EU" }
2. { Id: 2, Name: "Alison", Age: 22, Region: "NA" }
3. { Id: 3, Name: "Ana", Age: 25, Region: "EU" }
4. { Id: 4, Name: "Malik", Age: 30, Region: "BR" }

Uporabnik vnese:
- searchString = "ali"
- filterRegion = "EU"
- sortBy = "age_asc"

KORAK 1 - CONTAINS iskanje:
  playersQuery.Where(p => p.Name.ToLower().Contains("ali".ToLower()))
  Rezultat: 
  - "Milan" vsebuje "ali" ?
  - "Alison" vsebuje "ali" ?
  - "Ana" NE vsebuje "ali" ?
  - "Malik" vsebuje "ali" ?
  
  Ostane: [ Milan, Alison, Malik ]

KORAK 2 - WHERE filter:
  playersQuery.Where(p => p.Region == "EU")
  Rezultat:
  - Milan: Region = "EU" ?
  - Alison: Region = "NA" ?
  - Malik: Region = "BR" ?
  
  Ostane: [ Milan ]

KORAK 3 - ORDERBY sortiranje:
  playersQuery.OrderBy(p => p.Age)
  Rezultat:
  - Milan: Age = 28
  
  Ostane: [ Milan ]

KON�NI REZULTAT:
[ { Id: 1, Name: "Milan", Age: 28, Region: "EU" } ]
```

---

### Primer 2: Filtriranje Champions po statistiki

```csharp
// V ChampionsController.cs Index metodi:
if (!string.IsNullOrEmpty(filterStat) && filterStat != "All")
{
    championsQuery = filterStat switch
    {
        // Fizi�ni liki - WHERE z ve�je kot (>)
        "high_ad" => championsQuery.Where(c => c.Ad > 70),
        
        // Magi�ni liki - WHERE z ve�je kot (>)
        "high_ap" => championsQuery.Where(c => c.Ap > 70),
        
        // Tanki liki - WHERE z ve�je kot (>)
        "high_health" => championsQuery.Where(c => c.Health > 500),
        
        // Uravnote�eni liki - WHERE z AND (&&) - kombinacija pogojev
        "balanced" => championsQuery.Where(c => 
            c.Ad > 50 && c.Ap > 50 && c.Health > 400),
        
        _ => championsQuery
    };
}
```

**Primer z bazi:**
```
Liki v bazi:
1. { Name: "Garen", Ad: 85, Ap: 20, Health: 550 }    <- Fizi�ni
2. { Name: "Ahri", Ad: 40, Ap: 95, Health: 420 }     <- Magi�ni
3. { Name: "Teemo", Ad: 60, Ap: 65, Health: 380 }    <- Uravnote�en
4. { Name: "Blitzcrank", Ad: 65, Ap: 55, Health: 600 } <- Tank

Filtriranje "high_ad" (Ad > 70):
- Garen: 85 > 70 ?
- Ahri: 40 > 70 ?
- Teemo: 60 > 70 ?
- Blitzcrank: 65 > 70 ?
Rezultat: [ Garen ]

Filtriranje "balanced" (Ad > 50 && Ap > 50 && Health > 400):
- Garen: 85 > 50 ? && 20 > 50 ? && 550 > 400 ? = NE
- Ahri: 40 > 50 ? && 95 > 50 ? && 420 > 400 ? = NE
- Teemo: 60 > 50 ? && 65 > 50 ? && 380 > 400 ? = NE
- Blitzcrank: 65 > 50 ? && 55 > 50 ? && 600 > 400 ? = DA
Rezultat: [ Blitzcrank ]
```

---

## Razlaga switch stavka za sortiranje

```csharp
playersQuery = sortBy switch
{
    "name_asc" => playersQuery.OrderBy(p => p.Name),
    "name_desc" => playersQuery.OrderByDescending(p => p.Name),
    "age_asc" => playersQuery.OrderBy(p => p.Age),
    "age_desc" => playersQuery.OrderByDescending(p => p.Age),
    _ => playersQuery.OrderBy(p => p.Id)  // _ = default
};
```

**Kaj se zgodi?**
- �e je `sortBy = "name_asc"` -> sortiraj po imenu A-Z
- �e je `sortBy = "name_desc"` -> sortiraj po imenu Z-A
- �e je `sortBy = "age_asc"` -> sortiraj po starosti (od najmanj�e)
- �e je `sortBy = "age_desc"` -> sortiraj po starosti (od najve�je)
- �e je `sortBy` ne�to drugo (na primer "random") -> sortiraj po ID-u (privzeto)

---

## IQueryable vs ToList

**Pomembno razlikovanje:**

```csharp
// IQueryable - NIMA izvr�ena query �e
IQueryable<Player> query = _context.Players.Where(p => p.Age > 20);
// Ta vrstica se NE izvede �e v bazi!

// ToListAsync - IZVR�I query
var players = await query.ToListAsync();
// �ELE SEDAJ se vsa filtriranja izvr�ijo v bazi in prenese� podatke v aplikacijo
```

**Zakaj je to dobro?**
- Lahko nadaljuje� z dodajanjem pogojev (Where, OrderBy)
- Vsi filtri se izvr�ijo v bazi (je hitrej�e!)
- Samo ko pokli�e� `ToListAsync()`, se podatki prenesen v memorijo

---

## Primerjava WHERE, CONTAINS in ORDERBY

| Operacija | Kaj dela | Primer | SQL |
|-----------|----------|--------|-----|
| **WHERE** | Natan�na primerjava | `Where(p => p.Region == "EU")` | `WHERE Region = 'EU'` |
| **WHERE >** | Primerjava po vrednosti | `Where(c => c.Ad > 70)` | `WHERE Ad > 70` |
| **CONTAINS** | Iskanje v tekstu | `Where(p => p.Name.Contains("ali"))` | `WHERE Name LIKE '%ali%'` |
| **OrderBy** | Sortiraj A-Z / 0-9 | `OrderBy(p => p.Name)` | `ORDER BY Name ASC` |
| **OrderByDescending** | Sortiraj Z-A / 9-0 | `OrderByDescending(p => p.Age)` | `ORDER BY Age DESC` |

---

## Kombiniranje operacij - RAW PRIMER

```csharp
// Za�ni s prazno query
var query = _context.Players;

// Dodaj WHERE filter
query = query.Where(p => p.Age > 20);

// Dodaj CONTAINS iskanje
query = query.Where(p => p.Name.ToLower().Contains("ali"));

// Dodaj ORDERBY sortiranje
query = query.OrderBy(p => p.Name);

// Konvertuj v seznam
var results = await query.ToListAsync();
```

**Vsa tri filtriranja se izvr�ijo v SQL-u kot ena sama query:**
```sql
SELECT * FROM Players 
WHERE Age > 20 
AND LOWER(Name) LIKE LOWER('%ali%') 
ORDER BY Name ASC
```

---

## Prakti�ni namigi

### 1. Vedno preverite null ali prazen string

```csharp
// ? Slabo - bo crashal �e je searchString null
var results = _context.Players.Where(p => p.Name.Contains(searchString));

// ? Dobro - preverimo prvo
if (!string.IsNullOrEmpty(searchString))
{
    var results = _context.Players.Where(p => 
        p.Name.ToLower().Contains(searchString.ToLower()));
}
```

### 2. Uporabi ToLower() za case-insensitive iskanje

```csharp
// ? Slabo - ne najde� "Alison" �e i��e� "alison"
var results = _context.Players.Where(p => p.Name.Contains(search));

// ? Dobro - delujo� za vse variante
var results = _context.Players.Where(p => 
    p.Name.ToLower().Contains(search.ToLower()));
```

### 3. Filtri so kumulativni

```csharp
// Pravi red je VA�EN:
var query = _context.Players;
query = query.Where(...);           // Najprej filtriraj
query = query.Where(...);           // Potem znova filtriraj
query = query.OrderBy(...);         // Na koncu sortiraj

// Zakaj? Ker SQL optimizira WHERE stavke, ORDERBY pa vedno na koncu
```

---

## Zaklju�ek

- **WHERE** = filtrira podatke (==, >, <, &&, ||)
- **CONTAINS** = iskanje v tekstu (delno ujemanje)
- **ORDERBY** = sortira rezultate (A-Z ali 0-9)
- **IQueryable** = query se NE izvede �e (dopu��a kombiniranje)
- **ToListAsync()** = IZVR�IMO query in prenesemo rezultate

Vse tri operacije se izvr�ijo v bazi! To je hitro in u�inkovito.
