# League of Legends Management Application

## Opis

To je ASP.NET Core 8.0 aplikacija s Razor Pages/MVC arhitekturo, ki omogo�a upravljanje podatkov iz baze podatkov `league_of_legends` na stre�niku `DESKTOP-ULJC4LP\SQLEXPRESS`.

Aplikacija je bila generirana z **Database First** pristopom z uporabo Entity Framework Core 8.0 in `Scaffold-DbContext` ukaza.

## Zna�ilnosti

- **CRUD Operacije**: Ustvarjanje, branje, posodabljanje in brisanje podatkov
- **Modeli**: 
  - Players (Igralci)
  - Champions (Liki)
  - Items (Predmeti)
  - Ranks (Rang)
  - Masteries (Mojstrstva)
  - Roles (Vloge)
  - Abilities (Sposobnosti)
  - Runes (Rune)

- **Tehnologija**: 
  - ASP.NET Core 8.0
  - Entity Framework Core 8.0
  - SQL Server
  - Bootstrap 5 za UI

## Namestitev

### Predpogoji

- .NET 8.0 SDK
- SQL Server (DESKTOP-ULJC4LP\SQLEXPRESS)
- Baza podatkov `league_of_legends`

### Koraki namestitve

1. **Kloniraj projekt**
   ```bash
   git clone <repository-url>
   cd "League of legends"
   ```

2. **Obnovite NuGet pakete**
   ```bash
   dotnet restore
   ```

3. **Prilagodite connection string** (�e je potrebno)
   - Uredite datoteko `appsettings.json`
   - Spremenite vrednost `ConnectionStrings:DefaultConnection`

4. **Po�enite aplikacijo**
   ```bash
   dotnet run
   ```

5. **Dostopite do aplikacije**
   - Odprite brskalnik
   - Pojdite na `https://localhost:5001` (ali nakazani port)

## Dostopne podatkovne tabele

### Players
- **Id**: Unikatni identifikator
- **Name**: Ime igralca
- **Age**: Starost
- **Region**: Regija

### Champions
- **Id**: Unikatni identifikator
- **Name**: Ime lika
- **Lore**: Zgodba/Opis
- **Health**: Zdravje
- **Ad**: Attack Damage (Fizi�na �koda)
- **Ap**: Ability Power (Magi�na mo�)

### Items
- **Id**: Unikatni identifikator
- **Name**: Ime predmeta
- **Cost**: Cena v zlatu
- **Stats**: Statistike
- **PassiveEffects**: Pasivni u�inki

### Ranks
- **Id**: Unikatni identifikator
- **PlayerId**: ID igralca
- **Tier**: Stopnja (Iron, Bronze, Silver, Gold, Platinum, Diamond, Master, Grandmaster, Challenger)
- **Division**: Razdelitev
- **Points**: To�ke

### Masteries
- **Id**: Unikatni identifikator
- **PlayerId**: ID igralca
- **ChampId**: ID lika
- **MasteryLevel**: Raven mojstrstva
- **MasteryPoints**: To�ke mojstrstva

## API Kontrolerji

Aplikacija ima naslednje kontrolerje:

- `PlayersController` - Upravljanje igralcev
- `ChampionsController` - Upravljanje likov
- `ItemsController` - Upravljanje predmetov

Vsak kontroler podpira standardne CRUD operacije:
- `Index` - Prikaz vseh zapisov
- `Details` - Prikaz podrobnosti posameznega zapisa
- `Create` - Ustvarjanje novega zapisa
- `Edit` - Urejanje obstoje�ega zapisa
- `Delete` - Brisanje zapisa

## Struktura projektov

```
League of legends/
??? Controllers/
?   ??? HomeController.cs
?   ??? PlayersController.cs
?   ??? ChampionsController.cs
?   ??? ItemsController.cs
??? Models/
?   ??? LeagueOfLegendsContext.cs (DbContext)
?   ??? Player.cs
?   ??? Champion.cs
?   ??? Item.cs
?   ??? Rank.cs
?   ??? Mastery.cs
?   ??? Role.cs
?   ??? Ability.cs
?   ??? Rune.cs
??? Views/
?   ??? Home/
?   ?   ??? Index.cshtml
?   ?   ??? Privacy.cshtml
?   ??? Players/
?   ?   ??? Index.cshtml
?   ?   ??? Create.cshtml
?   ?   ??? Edit.cshtml
?   ?   ??? Delete.cshtml
?   ?   ??? Details.cshtml
?   ??? Champions/
?   ?   ??? Index.cshtml
?   ?   ??? Create.cshtml
?   ?   ??? Edit.cshtml
?   ?   ??? Delete.cshtml
?   ?   ??? Details.cshtml
?   ??? Items/
?       ??? Index.cshtml
?       ??? Create.cshtml
?       ??? Edit.cshtml
?       ??? Delete.cshtml
?       ??? Details.cshtml
??? appsettings.json
??? Program.cs
??? League of legends.csproj
```

## Razvojne opombe

### Generiranje modelov

Modeli so bili generirani z naslednjim ukazom:

```bash
dotnet-ef dbcontext scaffold "Server=DESKTOP-ULJC4LP\SQLEXPRESS;Database=league_of_legends;Trusted_Connection=true;TrustServerCertificate=true;" Microsoft.EntityFrameworkCore.SqlServer -o Models -f
```

### Paketi

- `Microsoft.EntityFrameworkCore.SqlServer` 8.0.0
- `Microsoft.EntityFrameworkCore.Tools` 8.0.0

## Licence

Ta projekt je odprte kode pod licenco MIT.

## Dodatno

Za ve� informacij o Entity Framework Core in ASP.NET Core obi��ite:
- https://learn.microsoft.com/aspnet/core
- https://learn.microsoft.com/ef/core/
