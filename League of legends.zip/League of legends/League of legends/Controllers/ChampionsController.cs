using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using League_of_legends.Models;

namespace League_of_legends.Controllers;

public class ChampionsController : Controller
{
    private readonly LeagueOfLegendsContext _context;

    public ChampionsController(LeagueOfLegendsContext context)
    {
        _context = context;
    }

    // GET: Champions
    // Iskalnik in filtriranje po imenu in statistiki
    public async Task<IActionResult> Index(string searchString, string filterStat, string sortBy)
    {
        // Za�ni z vsemi liki iz baze
        IQueryable<Champion> championsQuery = _context.Champions;

        // FILTRIRANJE PO IMENU - CONTAINS
        // LINQ WHERE + CONTAINS: i��e po delih imena (case-insensitive)
        // Primer: searchString = "Ahri" -> vrne vse like z "ahri" v imenu
        if (!string.IsNullOrEmpty(searchString))
        {
            championsQuery = championsQuery.Where(c => 
                c.Name.ToLower().Contains(searchString.ToLower()));
            // .Contains() - najde vsak string ki vsebuje iskani text
        }

        // FILTRIRANJE PO STATISTIKI - WHERE Z PRIMERJAVO
        // LINQ WHERE: natan�na primerjava vrednosti (>, <, ==)
        // Primer: filterStat = "high_ad" -> vrne like s sve�ajo AD
        if (!string.IsNullOrEmpty(filterStat) && filterStat != "All")
        {
            championsQuery = filterStat switch
            {
                // Fizi�ni liki - AD > 70
                "high_ad" => championsQuery.Where(c => c.Ad > 70),
                // Magi�ni liki - AP > 70
                "high_ap" => championsQuery.Where(c => c.Ap > 70),
                // Tanki liki - Health > 500
                "high_health" => championsQuery.Where(c => c.Health > 500),
                // Uravnote�eni liki - vsa tri > 50
                "balanced" => championsQuery.Where(c => 
                    c.Ad > 50 && c.Ap > 50 && c.Health > 400),
                _ => championsQuery
            };
        }

        // SORTIRANJE - ORDERBY/ORDERBY DESCENDING
        // LINQ OrderBy/OrderByDescending: sortira rezultate po izbrani koloni
        // Primer: sortBy = "name_asc" -> sortira po imenu a-z
        championsQuery = sortBy switch
        {
            // Sortiranje po imenu (A-Z)
            "name_asc" => championsQuery.OrderBy(c => c.Name),
            // Sortiranje po imenu (Z-A)
            "name_desc" => championsQuery.OrderByDescending(c => c.Name),
            // Sortiranje po AD (od najmanj�e)
            "ad_asc" => championsQuery.OrderBy(c => c.Ad),
            // Sortiranje po AD (od najve�je)
            "ad_desc" => championsQuery.OrderByDescending(c => c.Ad),
            // Sortiranje po AP (od najve�je)
            "ap_desc" => championsQuery.OrderByDescending(c => c.Ap),
            // Sortiranje po Health (od najve�je)
            "health_desc" => championsQuery.OrderByDescending(c => c.Health),
            // Privzeto sortiranje po ID-u
            _ => championsQuery.OrderBy(c => c.Id)
        };

        // Konvertuj query v seznam
        // ToListAsync() - izvede query v bazi in vrne rezultate
        var champions = await championsQuery.ToListAsync();

        // Po�lji podatke v view
        ViewData["SearchString"] = searchString;
        ViewData["FilterStat"] = filterStat;
        ViewData["SortBy"] = sortBy;

        return View(champions);
    }

    // GET: Champions/Details/5
    public async Task<IActionResult> Details(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var champion = await _context.Champions
            .FirstOrDefaultAsync(m => m.Id == id);
        if (champion == null)
        {
            return NotFound();
        }

        return View(champion);
    }

    // GET: Champions/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: Champions/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("Id,Name,Lore,Health,Ad,Ap")] Champion champion)
    {
        if (ModelState.IsValid)
        {
            _context.Add(champion);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        return View(champion);
    }

    // GET: Champions/Edit/5
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var champion = await _context.Champions.FindAsync(id);
        if (champion == null)
        {
            return NotFound();
        }
        return View(champion);
    }

    // POST: Champions/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Lore,Health,Ad,Ap")] Champion champion)
    {
        if (id != champion.Id)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            try
            {
                _context.Update(champion);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ChampionExists(champion.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return RedirectToAction(nameof(Index));
        }
        return View(champion);
    }

    // GET: Champions/Delete/5
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var champion = await _context.Champions
            .FirstOrDefaultAsync(m => m.Id == id);
        if (champion == null)
        {
            return NotFound();
        }

        return View(champion);
    }

    // POST: Champions/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var champion = await _context.Champions.FindAsync(id);
        if (champion != null)
        {
            _context.Champions.Remove(champion);
            await _context.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Index));
    }

    private bool ChampionExists(int id)
    {
        return _context.Champions.Any(e => e.Id == id);
    }
}
