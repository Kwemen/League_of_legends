using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using League_of_legends.Models;

namespace League_of_legends.Controllers;

public class PlayersController : Controller
{
    private readonly LeagueOfLegendsContext _context;

    public PlayersController(LeagueOfLegendsContext context)
    {
        _context = context;
    }

    // GET: Players
    // Iskalnik in filtriranje po imenu, starosti in regiji
    public async Task<IActionResult> Index(string searchString, string filterRegion, string sortBy)
    {
        // Za�ni z vsemi igralci iz baze
        IQueryable<Player> playersQuery = _context.Players;

        // FILTRIRANJE PO IMENU - CONTAINS
        // LINQ: WHERE + CONTAINS - i��e po delih besede (ne glede na velikost �rk)
        // Primer: �e je searchString = "ali", bo na�el "Alison", "Malik", itd.
        if (!string.IsNullOrEmpty(searchString))
        {
            playersQuery = playersQuery.Where(p => 
                p.Name.ToLower().Contains(searchString.ToLower()));
            // .ToLower() - pretvori besedo v male �rke za neob�utljivo primerjavo
            // .Contains() - preveri ali string vsebuje iskani text
        }

        // FILTRIRANJE PO REGIJI - WHERE Z ENAKOSTJO
        // LINQ: WHERE - natan�na primerjava vrednosti
        // Primer: filtrira samo igralce iz izbrane regije
        if (!string.IsNullOrEmpty(filterRegion) && filterRegion != "All")
        {
            playersQuery = playersQuery.Where(p => p.Region == filterRegion);
            // == - natan�na primerjava, ne delnih ujemanj
        }

        // SORTIRANJE - ORDERBY
        // LINQ: OrderBy/OrderByDescending - sortira po izbrani koloni
        playersQuery = sortBy switch
        {
            // Sortiranje po imenu (A-Z)
            "name_asc" => playersQuery.OrderBy(p => p.Name),
            // Sortiranje po imenu (Z-A)
            "name_desc" => playersQuery.OrderByDescending(p => p.Name),
            // Sortiranje po starosti (od najmanj�e)
            "age_asc" => playersQuery.OrderBy(p => p.Age),
            // Sortiranje po starosti (od najve�je)
            "age_desc" => playersQuery.OrderByDescending(p => p.Age),
            // Privzeto sortiranje po ID-u
            _ => playersQuery.OrderBy(p => p.Id)
        };

        // Konvertuj query v seznam in po�lji v view
        // ToListAsync() - izvede query v bazi in �aka rezultat
        var players = await playersQuery.ToListAsync();

        // Po�lji podatke v view
        ViewData["SearchString"] = searchString;
        ViewData["FilterRegion"] = filterRegion;
        ViewData["SortBy"] = sortBy;
        // Dostopne regije za dropdown
        ViewData["Regions"] = new[] { "All", "EU", "NA", "KR", "BR", "JP", "TR" };

        return View(players);
    }

    // GET: Players/Details/5
    public async Task<IActionResult> Details(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var player = await _context.Players
            .FirstOrDefaultAsync(m => m.Id == id);
        if (player == null)
        {
            return NotFound();
        }

        return View(player);
    }

    // GET: Players/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: Players/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("Id,Name,Age,Region")] Player player)
    {
        if (ModelState.IsValid)
        {
            _context.Add(player);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        return View(player);
    }

    // GET: Players/Edit/5
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var player = await _context.Players.FindAsync(id);
        if (player == null)
        {
            return NotFound();
        }
        return View(player);
    }

    // POST: Players/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Age,Region")] Player player)
    {
        if (id != player.Id)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            try
            {
                _context.Update(player);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PlayerExists(player.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return RedirectToAction(nameof(Index));
        }
        return View(player);
    }

    // GET: Players/Delete/5
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var player = await _context.Players
            .FirstOrDefaultAsync(m => m.Id == id);
        if (player == null)
        {
            return NotFound();
        }

        return View(player);
    }

    // POST: Players/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var player = await _context.Players.FindAsync(id);
        if (player != null)
        {
            _context.Players.Remove(player);
            await _context.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Index));
    }

    private bool PlayerExists(int id)
    {
        return _context.Players.Any(e => e.Id == id);
    }
}
