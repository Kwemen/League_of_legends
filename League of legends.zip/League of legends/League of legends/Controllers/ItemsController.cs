using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using League_of_legends.Models;

namespace League_of_legends.Controllers;

public class ItemsController : Controller
{
    private readonly LeagueOfLegendsContext _context;

    public ItemsController(LeagueOfLegendsContext context)
    {
        _context = context;
    }

    // GET: Items
    // Iskalnik in filtriranje po imenu in ceni
    public async Task<IActionResult> Index(string searchString, string filterCost, string sortBy)
    {
        // Za�ni z vsemi predmeti iz baze
        IQueryable<Item> itemsQuery = _context.Items;

        // FILTRIRANJE PO IMENU - CONTAINS
        // Iskanje po delih imena
        if (!string.IsNullOrEmpty(searchString))
        {
            itemsQuery = itemsQuery.Where(i => 
                i.Name.ToLower().Contains(searchString.ToLower()));
        }

        // FILTRIRANJE PO CENI - WHERE Z PRIMERJAVO
        // Filtriranje po cenovnih razredih
        if (!string.IsNullOrEmpty(filterCost) && filterCost != "All")
        {
            itemsQuery = filterCost switch
            {
                // Poceni predmeti - cena < 1000
                "cheap" => itemsQuery.Where(i => i.Cost < 1000),
                // Srednje dragi - cena 1000-2000
                "medium" => itemsQuery.Where(i => i.Cost >= 1000 && i.Cost < 2000),
                // Dragi - cena >= 2000
                "expensive" => itemsQuery.Where(i => i.Cost >= 2000),
                _ => itemsQuery
            };
        }

        // SORTIRANJE - ORDERBY
        itemsQuery = sortBy switch
        {
            "name_asc" => itemsQuery.OrderBy(i => i.Name),
            "name_desc" => itemsQuery.OrderByDescending(i => i.Name),
            "cost_asc" => itemsQuery.OrderBy(i => i.Cost),
            "cost_desc" => itemsQuery.OrderByDescending(i => i.Cost),
            _ => itemsQuery.OrderBy(i => i.Id)
        };

        // Konvertuj query v seznam
        var items = await itemsQuery.ToListAsync();

        // Po�lji podatke v view
        ViewData["SearchString"] = searchString;
        ViewData["FilterCost"] = filterCost;
        ViewData["SortBy"] = sortBy;

        return View(items);
    }

    // GET: Items/Details/5
    public async Task<IActionResult> Details(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var item = await _context.Items
            .FirstOrDefaultAsync(m => m.Id == id);
        if (item == null)
        {
            return NotFound();
        }

        return View(item);
    }

    // GET: Items/Create
    public IActionResult Create()
    {
        return View();
    }

    // POST: Items/Create
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create([Bind("Id,Name,Cost,Stats,PassiveEffects")] Item item)
    {
        if (ModelState.IsValid)
        {
            _context.Add(item);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        return View(item);
    }

    // GET: Items/Edit/5
    public async Task<IActionResult> Edit(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var item = await _context.Items.FindAsync(id);
        if (item == null)
        {
            return NotFound();
        }
        return View(item);
    }

    // POST: Items/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Cost,Stats,PassiveEffects")] Item item)
    {
        if (id != item.Id)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            try
            {
                _context.Update(item);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ItemExists(item.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return RedirectToAction(nameof(Index));
        }
        return View(item);
    }

    // GET: Items/Delete/5
    public async Task<IActionResult> Delete(int? id)
    {
        if (id == null)
        {
            return NotFound();
        }

        var item = await _context.Items
            .FirstOrDefaultAsync(m => m.Id == id);
        if (item == null)
        {
            return NotFound();
        }

        return View(item);
    }

    // POST: Items/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var item = await _context.Items.FindAsync(id);
        if (item != null)
        {
            _context.Items.Remove(item);
            await _context.SaveChangesAsync();
        }
        return RedirectToAction(nameof(Index));
    }

    private bool ItemExists(int id)
    {
        return _context.Items.Any(e => e.Id == id);
    }
}
