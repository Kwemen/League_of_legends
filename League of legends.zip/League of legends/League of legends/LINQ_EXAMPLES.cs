// LINQ PRIMERI - PREPROST REFERENCE GUIDE
// Uporabi te primere kot reference pri pisanju lastne kode

using System;
using System.Collections.Generic;
using System.Linq;

public class LinqExamplesClass
{
    // Recimo, da imamo podatke v listi
    public class Player
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Region { get; set; }
    }

    public class Champion
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Health { get; set; }
        public int Ad { get; set; }
        public int Ap { get; set; }
    }

    public static void Main()
    {
        // VZOR�NI PODATKI
        var players = new List<Player>
        {
            new() { Id = 1, Name = "Milan", Age = 28, Region = "EU" },
            new() { Id = 2, Name = "Alison", Age = 22, Region = "NA" },
            new() { Id = 3, Name = "Ana", Age = 25, Region = "EU" },
            new() { Id = 4, Name = "Malik", Age = 30, Region = "BR" },
            new() { Id = 5, Name = "Petra", Age = 20, Region = "EU" }
        };

        var champions = new List<Champion>
        {
            new() { Id = 1, Name = "Garen", Health = 550, Ad = 85, Ap = 20 },
            new() { Id = 2, Name = "Ahri", Health = 420, Ad = 40, Ap = 95 },
            new() { Id = 3, Name = "Teemo", Health = 380, Ad = 60, Ap = 65 },
            new() { Id = 4, Name = "Blitzcrank", Health = 600, Ad = 65, Ap = 55 }
        };

        // ============================================
        // PRIMER 1: WHERE - NATAN�NA PRIMERJAVA
        // ============================================
        Console.WriteLine("\n=== PRIMER 1: WHERE - Filtriranje ===");
        
        // Najdi vse igralce iz EU regije
        var euPlayers = players.Where(p => p.Region == "EU").ToList();
        Console.WriteLine("Igralci iz EU:");
        foreach (var p in euPlayers)
            Console.WriteLine($"  - {p.Name} ({p.Region})");
        // Rezultat: Milan, Ana, Petra

        // Najdi vse igralce starej�e od 25 let
        var seniorPlayers = players.Where(p => p.Age > 25).ToList();
        Console.WriteLine("\nIgralci starej�i od 25 let:");
        foreach (var p in seniorPlayers)
            Console.WriteLine($"  - {p.Name} ({p.Age} let)");
        // Rezultat: Milan, Malik

        // Kombinacija pogojev (AND)
        var euSeniors = players.Where(p => p.Region == "EU" && p.Age > 25).ToList();
        Console.WriteLine("\nIgralci iz EU in starej�i od 25 let:");
        foreach (var p in euSeniors)
            Console.WriteLine($"  - {p.Name} ({p.Region}, {p.Age} let)");
        // Rezultat: Milan

        // ============================================
        // PRIMER 2: CONTAINS - ISKANJE V TEKSTU
        // ============================================
        Console.WriteLine("\n=== PRIMER 2: CONTAINS - Iskanje ===");

        // Iskalnik: najdi vse like z "ash" v imenu
        string search1 = "ash";
        var championsWithAsh = champions.Where(c => 
            c.Name.ToLower().Contains(search1.ToLower())).ToList();
        Console.WriteLine($"Liki z '{search1}' v imenu:");
        foreach (var c in championsWithAsh)
            Console.WriteLine($"  - {c.Name}");
        // Rezultat: Blitzcrank (BLITSzrank) ne, "ash" ne obstaja

        // Iskalnik: najdi vse igralce z "ali" v imenu
        string search2 = "ali";
        var playersWithAli = players.Where(p => 
            p.Name.ToLower().Contains(search2.ToLower())).ToList();
        Console.WriteLine($"\nIgralci z '{search2}' v imenu:");
        foreach (var p in playersWithAli)
            Console.WriteLine($"  - {p.Name}");
        // Rezultat: Milan, Alison, Malik

        // ============================================
        // PRIMER 3: ORDERBY - SORTIRANJE NARA��AJO�E
        // ============================================
        Console.WriteLine("\n=== PRIMER 3: OrderBy - Sortiraj A-Z ===");

        // Sortiraj igralce po imenu A-Z
        var playersSortedByName = players.OrderBy(p => p.Name).ToList();
        Console.WriteLine("Igralci sortirani po imenu (A-Z):");
        foreach (var p in playersSortedByName)
            Console.WriteLine($"  - {p.Name}");
        // Rezultat: Alison, Ana, Malik, Milan, Petra

        // Sortiraj igralce po starosti (od najmanj�e)
        var playersSortedByAge = players.OrderBy(p => p.Age).ToList();
        Console.WriteLine("\nIgralci sortirani po starosti (od najmanj�e):");
        foreach (var p in playersSortedByAge)
            Console.WriteLine($"  - {p.Name} ({p.Age} let)");
        // Rezultat: Petra (20), Alison (22), Ana (25), Milan (28), Malik (30)

        // ============================================
        // PRIMER 4: ORDERBYDESCENDING - SORTIRANJE PADAJO�E
        // ============================================
        Console.WriteLine("\n=== PRIMER 4: OrderByDescending - Sortiraj Z-A ===");

        // Sortiraj igralce po imenu Z-A
        var playersSortedByNameDesc = players.OrderByDescending(p => p.Name).ToList();
        Console.WriteLine("Igralci sortirani po imenu (Z-A):");
        foreach (var p in playersSortedByNameDesc)
            Console.WriteLine($"  - {p.Name}");
        // Rezultat: Petra, Milan, Malik, Ana, Alison

        // Sortiraj like po zdravju (od najve�jega)
        var championsSortedByHealth = champions.OrderByDescending(c => c.Health).ToList();
        Console.WriteLine("\nLiki sortirani po zdravju (od najve�jega):");
        foreach (var c in championsSortedByHealth)
            Console.WriteLine($"  - {c.Name} ({c.Health} HP)");
        // Rezultat: Blitzcrank (600), Garen (550), Ahri (420), Teemo (380)

        // ============================================
        // PRIMER 5: KOMBINIRANJE - WHERE + WHERE + ORDERBY
        // ============================================
        Console.WriteLine("\n=== PRIMER 5: Kombiniranje operacij ===");

        // Najdi igralce iz EU, ki so starej�i od 22 let, sortirani po imenu
        var complexQuery = players
            .Where(p => p.Region == "EU")           // Filter 1: samo EU
            .Where(p => p.Age > 22)                 // Filter 2: samo starej�i od 22
            .OrderBy(p => p.Name)                   // Sortiraj po imenu
            .ToList();
        Console.WriteLine("EU igralci, starej�i od 22 let (sortirani po imenu):");
        foreach (var p in complexQuery)
            Console.WriteLine($"  - {p.Name} ({p.Region}, {p.Age} let)");
        // Rezultat: Ana, Milan

        // ============================================
        // PRIMER 6: SWITCH SORTIRANJE
        // ============================================
        Console.WriteLine("\n=== PRIMER 6: Switch za dinami�no sortiranje ===");

        // Simulacija sortBy parametra iz kontrolerja
        string sortBy = "age_desc";

        var sortedPlayers = sortBy switch
        {
            "name_asc" => players.OrderBy(p => p.Name).ToList(),
            "name_desc" => players.OrderByDescending(p => p.Name).ToList(),
            "age_asc" => players.OrderBy(p => p.Age).ToList(),
            "age_desc" => players.OrderByDescending(p => p.Age).ToList(),
            _ => players.OrderBy(p => p.Id).ToList()
        };

        Console.WriteLine($"Igralci sortirani po: {sortBy}");
        foreach (var p in sortedPlayers)
            Console.WriteLine($"  - {p.Name} ({p.Age} let)");
        // Rezultat (age_desc): Malik (30), Milan (28), Ana (25), Alison (22), Petra (20)

        // ============================================
        // PRIMER 7: FILTRIRANJE LIKE PO STATISTIKI
        // ============================================
        Console.WriteLine("\n=== PRIMER 7: Filtriranje like po statistiki ===");

        // Fizi�ni liki (Ad > 70)
        var physicalChampions = champions.Where(c => c.Ad > 70).ToList();
        Console.WriteLine("Fizi�ni liki (AD > 70):");
        foreach (var c in physicalChampions)
            Console.WriteLine($"  - {c.Name} (AD: {c.Ad})");
        // Rezultat: Garen

        // Magi�ni liki (Ap > 70)
        var magicalChampions = champions.Where(c => c.Ap > 70).ToList();
        Console.WriteLine("\nMagi�ni liki (AP > 70):");
        foreach (var c in magicalChampions)
            Console.WriteLine($"  - {c.Name} (AP: {c.Ap})");
        // Rezultat: Ahri

        // Uravnote�eni liki (Ad > 50 && Ap > 50 && Health > 400)
        var balancedChampions = champions.Where(c => 
            c.Ad > 50 && c.Ap > 50 && c.Health > 400).ToList();
        Console.WriteLine("\nUravnote�eni liki (AD > 50 && AP > 50 && Health > 400):");
        foreach (var c in balancedChampions)
            Console.WriteLine($"  - {c.Name} (AD: {c.Ad}, AP: {c.Ap}, Health: {c.Health})");
        // Rezultat: Blitzcrank

        // ============================================
        // PRIMER 8: ANY - PREVERI ALI OBSTAJA
        // ============================================
        Console.WriteLine("\n=== PRIMER 8: Any - Preveri obstoj ===");

        // Preveri ali obstaja igralec iz EU
        bool hasEUPlayer = players.Any(p => p.Region == "EU");
        Console.WriteLine($"Ali obstaja igralec iz EU? {(hasEUPlayer ? "DA" : "NE")}");
        // Rezultat: DA

        // Preveri ali obstaja lik z zdravjem > 500
        bool hasStrongChampion = champions.Any(c => c.Health > 500);
        Console.WriteLine($"Ali obstaja lik z zdravjem > 500? {(hasStrongChampion ? "DA" : "NE")}");
        // Rezultat: DA

        // ============================================
        // PRIMER 9: COUNT - PRE�TEJ
        // ============================================
        Console.WriteLine("\n=== PRIMER 9: Count - Pre�tej ===");

        // Pre�tej igralce iz EU
        int euPlayerCount = players.Where(p => p.Region == "EU").Count();
        Console.WriteLine($"�tevilo igralcev iz EU: {euPlayerCount}");
        // Rezultat: 3

        // Pre�tej like z AP > 50
        int magicChampionCount = champions.Where(c => c.Ap > 50).Count();
        Console.WriteLine($"�tevilo like z AP > 50: {magicChampionCount}");
        // Rezultat: 2 (Ahri, Teemo, Blitzcrank)

        // ============================================
        // PRIMER 10: FIRST / FIRSTORDEFAULT
        // ============================================
        Console.WriteLine("\n=== PRIMER 10: First - Vzemi prvo ===");

        // Vzemi prvega igralca iz EU, ki je starej�i od 25 let
        var firstSenior = players
            .Where(p => p.Region == "EU" && p.Age > 25)
            .FirstOrDefault();
        
        if (firstSenior != null)
            Console.WriteLine($"Prvi senior iz EU: {firstSenior.Name}");
        // Rezultat: Milan

        // Vzemi prvega lika z najvi�jim AP
        var maxAPChampion = champions.OrderByDescending(c => c.Ap).FirstOrDefault();
        if (maxAPChampion != null)
            Console.WriteLine($"Lik z najve�jim AP: {maxAPChampion.Name} (AP: {maxAPChampion.Ap})");
        // Rezultat: Ahri
    }
}
