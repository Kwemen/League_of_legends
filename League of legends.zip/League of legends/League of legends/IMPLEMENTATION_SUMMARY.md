# ?? Iskalnik in Filtriranje - Povzetek Implementacije

## ? Kaj je bilo implementirano?

### ?? 1. Tri polne LINQ implementacije iskanja

#### PlayersController.Index()
- **Iskalnik**: Po imenu (WHERE + CONTAINS)
- **Filter**: Po regiji - EU, NA, KR, BR, JP, TR (WHERE ==)
- **Sortiranje**: Po imenu (A-Z / Z-A) ali starosti

#### ChampionsController.Index()
- **Iskalnik**: Po imenu (WHERE + CONTAINS)
- **Filter**: Po tipu (Fizi�ni, Magi�ni, Tanki, Uravnote�eni)
- **Sortiranje**: Po imenu, AD, AP ali zdravju

#### ItemsController.Index()
- **Iskalnik**: Po imenu (WHERE + CONTAINS)
- **Filter**: Po ceni (Poceni, Srednje, Dragi)
- **Sortiranje**: Po imenu ali ceni

---

## ?? LINQ Operacije - Pregled

### 1. WHERE - Filtriranje

```csharp
// Natan�na primerjava
.Where(p => p.Region == "EU")

// Primerjava vrednosti
.Where(c => c.Ad > 70)

// Kombinacija (AND)
.Where(p => p.Region == "EU" && p.Age > 25)
```

### 2. CONTAINS - Iskanje v Tekstu

```csharp
// Case-insensitive iskanje
.Where(p => p.Name.ToLower().Contains(search.ToLower()))

// Rezultat: "ALI" najde "Alison", "Malik", "Milan"
```

### 3. ORDERBY - Sortiranje

```csharp
// Nara��ajo�e (A-Z, 0-9)
.OrderBy(p => p.Name)
.OrderBy(p => p.Age)

// Padajo�e (Z-A, 9-0)
.OrderByDescending(p => p.Age)
.OrderByDescending(c => c.Health)
```

---

## ?? Kako deluje v praksi?

### URL Zahteva
```
GET /Players/Index?searchString=ali&filterRegion=EU&sortBy=name_asc
```

### Kontroler
```csharp
public async Task<IActionResult> Index(
    string searchString,    // "ali"
    string filterRegion,    // "EU"
    string sortBy)          // "name_asc"
{
    IQueryable<Player> query = _context.Players;
    
    // 1. Iskalnik
    if (!string.IsNullOrEmpty(searchString))
        query = query.Where(p => p.Name.ToLower().Contains(searchString.ToLower()));
    
    // 2. Filter
    if (!string.IsNullOrEmpty(filterRegion) && filterRegion != "All")
        query = query.Where(p => p.Region == filterRegion);
    
    // 3. Sortiranje
    query = sortBy switch
    {
        "name_asc" => query.OrderBy(p => p.Name),
        "name_desc" => query.OrderByDescending(p => p.Name),
        _ => query.OrderBy(p => p.Id)
    };
    
    // 4. Konvertuj
    var players = await query.ToListAsync();
    
    return View(players);
}
```

### View - Forma
```html
<form method="get" asp-action="Index">
    <input type="text" name="searchString" placeholder="Iskalni tekst..." />
    <select name="filterRegion">
        <option value="All">All</option>
        <option value="EU">EU</option>
        <option value="NA">NA</option>
    </select>
    <select name="sortBy">
        <option value="">Default</option>
        <option value="name_asc">Name A-Z</option>
        <option value="name_desc">Name Z-A</option>
    </select>
    <button type="submit">Search</button>
</form>
```

---

## ?? Primeri Rezultatov

### Primer 1: Iskanje "ali" brez filtrov
```
Vhod: searchString = "ali", filterRegion = "", sortBy = ""
Rezultat:
  - Milan (28, EU)
  - Alison (22, NA)
  - Malik (30, BR)
```

### Primer 2: Filter "EU" brez iskanja
```
Vhod: searchString = "", filterRegion = "EU", sortBy = ""
Rezultat:
  - Milan (28, EU)
  - Ana (25, EU)
  - Petra (20, EU)
```

### Primer 3: Iskanje + Filter + Sortiranje
```
Vhod: searchString = "ali", filterRegion = "EU", sortBy = "name_asc"
Rezultat:
  - Milan (28, EU)
```

---

## ??? Datoteke za Referen�o

### Dokumentacija
- **LINQ_GUIDE.md** - Detaljne razlage (30+ primerov)
- **SEARCH_FILTER_GUIDE.md** - Prakti�ni vodnik
- **LINQ_VISUAL_GUIDE.md** - Vizualni diagrami
- **LINQ_QUICK_REFERENCE.md** - Hitri pregled
- **LINQ_EXAMPLES.cs** - Kodni primeri (10+ scenarijev)

### Koda
- **PlayersController.cs** - Iskanje igralcev
- **ChampionsController.cs** - Iskanje likov
- **ItemsController.cs** - Iskanje predmetov

### Views
- **Views/Players/Index.cshtml** - Forma + tabela
- **Views/Champions/Index.cshtml** - Forma + tabela
- **Views/Items/Index.cshtml** - Forma + tabela

---

## ?? Kaj se zgodi v SQL-u?

### Players - Iskanje + Filter + Sortiranje
```sql
SELECT * FROM Players
WHERE LOWER(Name) LIKE LOWER('%ali%')
AND Region = 'EU'
ORDER BY Name ASC
```

### Champions - Filtriranje po statistiki
```sql
SELECT * FROM Champions
WHERE Ad > 70
ORDER BY Id ASC
```

### Items - Filtriranje po ceni
```sql
SELECT * FROM Items
WHERE Cost >= 1000 AND Cost < 2000
ORDER BY Name ASC
```

---

## ?? Klju�ne To�ke

### 1. WHERE - Naredi tri stvari
```csharp
// Natan�na primerjava
.Where(p => p.Region == "EU")

// Primerjava vrednosti (>, <, !=)
.Where(c => c.Ad > 70)

// Ve� pogojev (AND)
.Where(p => p.Region == "EU" && p.Age > 25)
```

### 2. CONTAINS - Delno ujemanje
```csharp
// ? Natan�na iskanja - ne deluje dobro
.Where(p => p.Name == "Milan")  // samo to�no "Milan"

// ? CONTAINS - delno iskanja - DOBRO
.Where(p => p.Name.Contains("il"))  // "Milan", "Alison"
```

### 3. ORDERBY - Vrstni Red
```csharp
// Pravilno
query = query.Where(...);      // Filtriraj najprej
query = query.OrderBy(...);    // Sortiraj na koncu

// ? Naredi druga�e
query = query.OrderBy(...);    // Prvo sortiraj
query = query.Where(...);      // Potem filtriraj - po�ajno!
```

### 4. IQueryable vs ToList
```csharp
// ? Dobro - filtriraj v bazi
var results = await _context.Players
    .Where(...)
    .ToListAsync();

// ? Slabo - prenesi vse, potem filtriraj
var results = _context.Players.ToList()
    .Where(...);
```

---

## ?? Kako Testirati?

1. **Po�eni aplikacijo:**
   ```bash
   dotnet run
   ```

2. **Pojdi na Players:**
   ```
   https://localhost:5001/Players
   ```

3. **Testiraj Iskanje:**
   - Vnesi: "ali"
   - Klikni: "Search"
   - Rezultat: Milan, Alison, Malik

4. **Testiraj Filter:**
   - Izberi: "EU"
   - Klikni: "Search"
   - Rezultat: Milan, Ana, Petra

5. **Testiraj Kombinacijo:**
   - Vnesi: "ali"
   - Izberi Filter: "EU"
   - Izberi Sortiranje: "Name A-Z"
   - Klikni: "Search"
   - Rezultat: Milan

---

## ?? Dodatne Operacije

V LINQ_EXAMPLES.cs si ogleda� tudi:

```csharp
// ANY - Preveri obstoj
players.Any(p => p.Region == "EU")
// Rezultat: true ali false

// COUNT - Pre�tej
players.Where(p => p.Region == "EU").Count()
// Rezultat: 3

// FIRST - Vzemi prvega
players.First(p => p.Region == "EU")
// Rezultat: Milan

// SUM - Se�tej
players.Sum(p => p.Age)
// Rezultat: 135 (28+22+25+30+20)

// MAX - Najdi najve�jega
players.Max(p => p.Age)
// Rezultat: 30

// MIN - Najdi najmanj�ega
players.Min(p => p.Age)
// Rezultat: 20
```

---

## ? Povzetek - Tri Glavne LINQ Operacije

| Operacija | Kaj dela | SQL |
|-----------|----------|-----|
| **WHERE** | Filtrira podatke | `WHERE ...` |
| **CONTAINS** | Iskanje v besedilu | `LIKE '%..%'` |
| **ORDERBY** | Sortira rezultate | `ORDER BY ...` |

---

## ?? Kako Dodati Nov Filter?

### Primer: Dodaj filter po stanosti Players

**1. Kontroler:**
```csharp
if (!string.IsNullOrEmpty(filterAge))
{
    query = filterAge switch
    {
        "young" => query.Where(p => p.Age < 25),
        "senior" => query.Where(p => p.Age >= 25),
        _ => query
    };
}
```

**2. View:**
```html
<select name="filterAge">
    <option value="">All Ages</option>
    <option value="young">Young (< 25)</option>
    <option value="senior">Senior (>= 25)</option>
</select>
```

**3. ViewData:**
```csharp
ViewData["FilterAge"] = filterAge;
```

---

## ?? Zaklju�ek

Vzorec je enak za vse tri kontrolerje:
1. Prejmi parametre (searchString, filter, sortBy)
2. Za�ni z IQueryable
3. Dodaj WHERE filtri
4. Dodaj WHERE + CONTAINS iskanje
5. Dodaj OrderBy sortiranje
6. Konvertuj z ToListAsync()
7. Po�lji v View

Vse tri kode imajo enak vzorec, samo razli�ne podatke in filtri!
