# Iskalnik in Filtriranje - Prakti�ni Vodnik

## ?? Pregled implementacije

Ta aplikacija ima polno implementiran iskalnik in filtriranje s filtriranjem po spustnem seznamu (dropdown) v naslednjih straneh:

### 1. **Players (Igralci)**
   - **Iskalnik**: Po imenu (CONTAINS)
   - **Filter**: Po regiji (WHERE ==)
   - **Sortiranje**: Po imenu ali starosti

### 2. **Champions (Liki)**
   - **Iskalnik**: Po imenu (CONTAINS)
   - **Filter**: Po tipu lika (WHERE >)
   - **Sortiranje**: Po imenu, AD, AP ali Health

### 3. **Items** (privzeto nima filtriranja, lahko ga dodam)

---

## ?? Kako deluje iskalnik?

### Korak 1: Uporabnik vnese iskalne podatke

Uporabnik bo videl formo na spletni strani:
```
[Iskalni tekst: "ali"  ]
[Dropdown: "EU"       ]  ? Filter
[Dropdown: "Name A-Z" ]  ? Sortiranje
[Tipka: "Search"      ]
```

### Korak 2: Forma po�lje podatke v kontroler

Ko klikne na "Search", se po�ljejo parametri:
```
GET /Players/Index?searchString=ali&filterRegion=EU&sortBy=name_asc
```

### Korak 3: Kontroler filtrira podatke

V `PlayersController.Index()` se izvr�ijo LINQ operacije:

```csharp
// 1. WHERE + CONTAINS - Iskanje po imenu
playersQuery = playersQuery.Where(p => 
    p.Name.ToLower().Contains("ali".ToLower()));

// 2. WHERE - Filter po regiji
playersQuery = playersQuery.Where(p => p.Region == "EU");

// 3. ORDERBY - Sortiranje
playersQuery = playersQuery.OrderBy(p => p.Name);

// 4. ToListAsync - Izvr�imo query in prenesemo rezultate
var players = await playersQuery.ToListAsync();
```

### Korak 4: View prika�e rezultate

Uporabnik vidi samo filtriran seznam igralcev.

---

## ?? Kako je implementirano v kodu?

### A. KONTROLER - PlayersController.cs

```csharp
public async Task<IActionResult> Index(
    string searchString,      // Parameter: "ali"
    string filterRegion,      // Parameter: "EU"
    string sortBy)            // Parameter: "name_asc"
{
    // Za�ni z vsemi igralci
    IQueryable<Player> playersQuery = _context.Players;

    // 1. ISKALNIK - WHERE + CONTAINS
    if (!string.IsNullOrEmpty(searchString))
    {
        playersQuery = playersQuery.Where(p => 
            p.Name.ToLower().Contains(searchString.ToLower()));
    }

    // 2. FILTER - WHERE ==
    if (!string.IsNullOrEmpty(filterRegion) && filterRegion != "All")
    {
        playersQuery = playersQuery.Where(p => p.Region == filterRegion);
    }

    // 3. SORTIRANJE - ORDERBY
    playersQuery = sortBy switch
    {
        "name_asc" => playersQuery.OrderBy(p => p.Name),
        "name_desc" => playersQuery.OrderByDescending(p => p.Name),
        "age_asc" => playersQuery.OrderBy(p => p.Age),
        "age_desc" => playersQuery.OrderByDescending(p => p.Age),
        _ => playersQuery.OrderBy(p => p.Id)
    };

    // 4. KONVERTUJ V SEZNAM
    var players = await playersQuery.ToListAsync();

    // 5. PO�LJI PODATKE V VIEW
    ViewData["SearchString"] = searchString;
    ViewData["FilterRegion"] = filterRegion;
    ViewData["SortBy"] = sortBy;
    ViewData["Regions"] = new[] { "All", "EU", "NA", "KR", "BR", "JP", "TR" };

    return View(players);
}
```

### B. VIEW - Views/Players/Index.cshtml

```html
<!-- FORMA ZA ISKANJE IN FILTRIRANJE -->
<form method="get" asp-action="Index">
    <div class="row g-3">
        <!-- 1. ISKALNIK -->
        <div class="col-md-4">
            <label for="searchString">Search by Name</label>
            <input type="text" 
                   name="searchString" 
                   placeholder="Enter player name..." 
                   value="@ViewData["SearchString"]" />
        </div>

        <!-- 2. FILTER (DROPDOWN) -->
        <div class="col-md-3">
            <label for="filterRegion">Filter by Region</label>
            <select name="filterRegion">
                @foreach (var region in (string[])ViewData["Regions"])
                {
                    <option value="@region" 
                            selected="@(ViewData["FilterRegion"]?.ToString() == region)">
                        @region
                    </option>
                }
            </select>
        </div>

        <!-- 3. SORTIRANJE (DROPDOWN) -->
        <div class="col-md-3">
            <label for="sortBy">Sort by</label>
            <select name="sortBy">
                <option value="">Default (ID)</option>
                <option value="name_asc">Name (A-Z)</option>
                <option value="name_desc">Name (Z-A)</option>
                <option value="age_asc">Age (Low to High)</option>
                <option value="age_desc">Age (High to Low)</option>
            </select>
        </div>

        <!-- 4. TIPKA ZA ISKANJE -->
        <div class="col-md-2">
            <button type="submit">Search</button>
        </div>
    </div>
</form>

<!-- PRIKAZ REZULTATOV -->
@if (Model.Any())
{
    <table>
        @foreach (var item in Model)
        {
            <tr>
                <td>@item.Name</td>
                <td>@item.Age</td>
                <td>@item.Region</td>
            </tr>
        }
    </table>
}
```

---

## ?? Prakti�ni primeri uporabe

### Primer 1: Iskalnik brez filtrov

**Kaj naredi uporabnik:**
1. Vnese "ali" v iskalno polje
2. Klikne "Search"

**Kaj se zgodi v kontrolerju:**
```csharp
// Where + Contains - najde vse z "ali" v imenu
playersQuery.Where(p => p.Name.ToLower().Contains("ali".ToLower()))
// Rezultat: Milan, Alison, Malik
```

**Kaj vidi uporabnik:**
```
Milan   (28 let, EU)
Alison  (22 let, NA)
Malik   (30 let, BR)
```

---

### Primer 2: Filtriranje brez iskanja

**Kaj naredi uporabnik:**
1. Izbere "EU" v dropdown za regijo
2. Klikne "Search"

**Kaj se zgodi v kontrolerju:**
```csharp
// Where == - samo EU
playersQuery.Where(p => p.Region == "EU")
// Rezultat: Milan, Ana, Petra
```

**Kaj vidi uporabnik:**
```
Milan   (28 let, EU)
Ana     (25 let, EU)
Petra   (20 let, EU)
```

---

### Primer 3: Iskanje + Filter + Sortiranje

**Kaj naredi uporabnik:**
1. Vnese "ali" v iskalno polje
2. Izbere "EU" v dropdown
3. Izbere "Age (High to Low)" za sortiranje
4. Klikne "Search"

**Kaj se zgodi v kontrolerju:**
```csharp
// Korak 1: Where + Contains - iskanje
playersQuery.Where(p => p.Name.ToLower().Contains("ali"))
// Rezultat: Milan, Alison, Malik

// Korak 2: Where == - filter
playersQuery.Where(p => p.Region == "EU")
// Rezultat: Milan

// Korak 3: OrderByDescending - sortiranje
playersQuery.OrderByDescending(p => p.Age)
// Rezultat: Milan (28)

// Korak 4: ToListAsync - konvertuj
var players = await playersQuery.ToListAsync()
// Rezultat: [ Milan ]
```

**Kaj vidi uporabnik:**
```
Milan   (28 let, EU)
```

---

### Primer 4: Filtriranje like po statistiki

V ChampionsController je bolj napredna filtriranja:

```csharp
"high_ad" => championsQuery.Where(c => c.Ad > 70)
// Rezultat: Samo liki z Ad > 70

"balanced" => championsQuery.Where(c => 
    c.Ad > 50 && c.Ap > 50 && c.Health > 400)
// Rezultat: Samo uravnote�eni liki
```

---

## ??? Kako dodati nov filter?

### Korak 1: Dodaj parameter v kontroler

```csharp
public async Task<IActionResult> Index(
    string searchString,
    string filterRegion,
    string sortBy,
    string filterAge = "")  // ? NOVI FILTER
{
    ...
}
```

### Korak 2: Dodaj logiko za filter

```csharp
// Filtriranje po starosti
if (!string.IsNullOrEmpty(filterAge))
{
    filterAge switch
    {
        "young" => playersQuery.Where(p => p.Age < 25),
        "senior" => playersQuery.Where(p => p.Age >= 25),
        _ => playersQuery
    };
}
```

### Korak 3: Dodaj select polje v view

```html
<select name="filterAge">
    <option value="">All Ages</option>
    <option value="young">Young (< 25)</option>
    <option value="senior">Senior (>= 25)</option>
</select>
```

### Korak 4: Po�lji v ViewData

```csharp
ViewData["FilterAge"] = filterAge;
```

---

## ?? SQL ki se izvr�uje v bazi

Ko uporabnik i��e in filtrira, se v bazi izvr�ijo naslednji SQL stavki:

### Primer: Iskanje "ali" + Filter "EU" + Sortiranje

```sql
SELECT * FROM Players 
WHERE LOWER(Name) LIKE LOWER('%ali%')
AND Region = 'EU'
ORDER BY Name ASC
```

### Za like - Iskanje "ash" + Filter "high_ad"

```sql
SELECT * FROM Champions 
WHERE LOWER(Name) LIKE LOWER('%ash%')
AND Ad > 70
ORDER BY Id ASC
```

---

## ?? Pomembne napomene

### 1. Preverite null vrednosti
```csharp
// ? Slabo
if (searchString == null) { ... }

// ? Dobro
if (string.IsNullOrEmpty(searchString)) { ... }
```

### 2. Vedno uporabite ToLower() za case-insensitive iskanje
```csharp
// ? Ne deluje - "ALI" ne bo na�el "ali"
p.Name.Contains(searchString)

// ? Deluje - najde vse variante
p.Name.ToLower().Contains(searchString.ToLower())
```

### 3. Sortiranje na koncu
```csharp
// ? Naredi druga�e
query = query.OrderBy(p => p.Name);
query = query.Where(p => p.Age > 20);

// ? Pravilno
query = query.Where(p => p.Age > 20);
query = query.OrderBy(p => p.Name);
```

### 4. Ohrani vrednosti v ViewData
```csharp
// Tako lahko prika�e izbrane filtere v HTML
ViewData["SearchString"] = searchString;
ViewData["FilterRegion"] = filterRegion;
```

---

## ?? Povzetek

| Kaj | Kje | Kako |
|-----|-----|------|
| **Iskalnik** | Kontroler | `Where + Contains` |
| **Filter** | Kontroler | `Where + ==` ali `Where + >` |
| **Sortiranje** | Kontroler | `OrderBy` ali `OrderByDescending` |
| **Forma** | View | `<form method="get">` |
| **Dropdown** | View | `<select name="...">` |
| **Rezultati** | View | `@foreach (var item in Model)` |

---

## ?? Kako testirati?

1. Po�eni aplikacijo: `dotnet run`
2. Pojdi na `https://localhost:5001/Players`
3. Vnesi iskalni tekst (npr. "ali")
4. Izberi filter (npr. "EU")
5. Izberi sortiranje (npr. "Name A-Z")
6. Klikni "Search"
7. Vidi� filtrirane rezultate!

Isti proces deluje tudi za Champions in Items.
